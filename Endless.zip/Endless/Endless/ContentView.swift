//
//  ContentView.swift
//  Endless
//
//  Created by Александр on 30.10.2024.
//

import SwiftUI

struct ContentView: View {
    
    @State var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            
                Text("Feed")
                    .tabItem {
                        Image(systemName: "newspaper.circle.fill")
                        Text("Feed")
                }
                .tag(0)
                
                Text("Search")
                    .tabItem {
                        Image(systemName: "magnifyingglass.circle.fill")
                        Text("Search")
                    }
                    .tag(1)
                
                Text("Write")
                    .tabItem {
                        Image(systemName: "pencil.circle.fill")
                        Text("Write")
                    }
                    .tag(2)
                
                Text("Library")
                    .tabItem {
                        Image(systemName: "books.vertical.circle.fill")
                        Text("Library")
                    }
                    .tag(3)
                
                Text("Profile")
                    .tabItem {
                        Image(systemName: "person.circle.fill")
                        Text("Profile")
                    }
                    .tag(4)
            }
    }
}

#Preview {
    ContentView()
}
