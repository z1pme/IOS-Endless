//
//  EndlessApp.swift
//  Endless
//
//  Created by Александр on 30.10.2024.
//

import SwiftUI

@main
struct EndlessApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
