//
//  FeedUIView.swift
//  Endless
//
//  Created by Александр on 30.10.2024.
//

import SwiftUI

struct FeedUIView: View {
    var body: some View {
        ScrollView {
            NavBarFeedUIView()
            Image("imageStory1")
        }
    }
}

#Preview {
    FeedUIView()
}
