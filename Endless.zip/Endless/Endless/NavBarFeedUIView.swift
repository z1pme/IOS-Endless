//
//  NavBarFeedUIView.swift
//  Endless
//
//  Created by Александр on 30.10.2024.
//

import SwiftUI

struct NavBarFeedUIView: View {
    var body: some View {
        VStack {
            HStack {
                Image("logoEnds")
                
                Spacer()
                
                HStack {
                    Text("@ne_asanka")
                        .font(.caption)
            
                    Image("profilePhoto")
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
    }
}

#Preview {
    NavBarFeedUIView()
}
